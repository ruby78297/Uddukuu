import React from "react";
import Navbar from "./Banner/Navbar/Navbar";
import "./Explore.css";
const Explore = () => {
  return (
    <div>
      {/* <div class="explore-banner">
        <Navbar />
      </div>
      <div class="explore-card"></div> */}
      <div class="explore-footer"></div>
    </div>
  );
};
export default Explore;
