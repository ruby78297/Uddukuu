import React from "react";
import "./SectionBreaker2.css";

const ServiceBreaker2 = () => {
  return (
    <div className="row section-Wraper">
      <div className=" section-Wraper-1">
        <div >
          <h2 className="section-Wraper-0-content">How Udukku works</h2>
        </div>
        <div className='section-wrapper-content-1'>
          <h4 className="section-Wraper-1-content Wraper-1-content ">
            {" "}
            Trust Udukku, We will give a shape to your talent{" "}
          </h4>
        </div>
        <div>
          <h4 className="section-Wraper-1-content  Wraper-2-content">
            {" "}
            Trust Udukku, We will give a shape to your talent{" "}
          </h4>
        </div>
        <div>
          <h4 className="section-Wraper-1-content   Wraper-3-content ">
            {" "}
            Trust Udukku, We will give a shape to your talent{" "}
          </h4>
        </div>
      </div>

      <div className="col-sm section-breaker-image"></div>
    </div>
  );
};

export default ServiceBreaker2;
