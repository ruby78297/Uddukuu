import React from "react";
import AllCatBanner from "./AllCatBanner";

const AllCatTitle = () => {
  return <div className="text-center text-3xl font-bold all-cat-title">More Categories </div>;
};
export default AllCatTitle;
