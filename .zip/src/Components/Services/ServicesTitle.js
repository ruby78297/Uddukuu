import React from "react";

const ServicesTitle = () => {
  return (
    <div className="services-title">Discover Top Music Production Pros</div>
  );
};
export default ServicesTitle;
