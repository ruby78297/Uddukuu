export const CardData = [
  {
    id: 1,
    title: "Producers",
    des: "Hire and work with top producers, Ready to turn your work into HITS",
    image: "",
  },
  {
    id: 2,
    title: "Singers",
    des: "Discover the top singers to give voice to your music",
    image: "",
  },
  {
    id: 3,
    title: "Mixing Engineers",
    des: "Engineers are everywhere right, Hire one to turn your song release ready",
    image: "",
  },
  {
    id: 4,
    title: "Songwriters",
    des: "Connect to the magicians with pen to bring your thoughts on paper",
    image: "",
  },
  {
    id: 5,
    title: "Mastering Engineers",
    des: "Best in field mastering engineers in every price and genre for hire",
    image: "",
  },
  {
    id: 6,
    title: "Instrumentalists",
    des: "Key to hit your music, hire from our best Session musicians",
    image: "",
  },
];
