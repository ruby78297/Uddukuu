export const SliderData = [
  {
    id: 1,
    title: "Title-1",
    des: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    image:
      "https://images.unsplash.com/photo-1453090927415-5f45085b65c0?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=731&q=80",
  },
  {
    id: 2,
    title: "Title-2",
    des: "Contrary to popular belief, Lorem Ipsum is not simply random text. .",
    image:
      "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80",
  },
  {
    id: 3,
    title: "Title-3",
    des: "It is a long established fact that a reader will be distracted by the readable content of a page when ",
    image:
      "https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=667&q=80",
  },
  {
    id: 4,
    title: "Title-4",
    des: "There are many variations of passages of Lorem Ipsum available",
    image:
      "https://images.unsplash.com/photo-1478147427282-58a87a120781?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=750&q=80",
  },
  {
    id: 5,
    title: "Title-5",
    des: "All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary ",
    image:
      "https://images.unsplash.com/photo-1565103420311-8cbbc3cd87b8?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80",
  },
  {
    id: 6,
    title: "Title-6",
    des: "It has survived not only five centuries, but also the leap into electronic typesetting.",
    image:
      "https://images.unsplash.com/photo-1468392788711-903a924761a6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=765&q=80",
  },
];
