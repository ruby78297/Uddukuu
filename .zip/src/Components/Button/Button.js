import React from 'react'
import "./Button.css"
 const Bbutton = () => {
    return (
        <div>
            <button className="btn-get-started"></button>
        </div>
    )
}
export default Bbutton;