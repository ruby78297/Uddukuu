import React from "react";
import SpDashboardNav from "../../SpDashboardNav";

const SpPayment = () => {
  return (
    <div>
      <SpDashboardNav />
    </div>
  );
};
export default SpPayment;
