import React from "react";

const SoundBankLicenceCard = () => {
  return (
    <div>
      <div>name</div>
      <div>View Licenses / View FAQ</div>
      <div className="licence-card"></div>
    </div>
  );
};
export default SoundBankLicenceCard;
