import React from "react";
import AllCatBanner from "./AllCatBanner";

const AllCatTitle = () => {
  return <div className="text-center text-xl"> More Categories </div>;
};
export default AllCatTitle;
