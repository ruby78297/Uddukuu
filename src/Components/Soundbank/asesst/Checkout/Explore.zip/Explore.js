import React from "react";
import Navbar from "./Banner/Navbar/Navbar";
import "./Explore.css";

const Explore = () => {
  return (
    <div>
      <div
        className="cart-navbar"
        style={{ backgroundColor: "black", height: "15vh" }}
      >
        <Navbar />
      </div>
      <div className="cart-main-body">
        <div className="cart-form">
          <h2>Licensee Information</h2>
          <form className="cart-form-input">
            <div className="form-names">
              <div>
                <input
                  type="text"
                  placeholder="Enter your name"
                  className="input"
                  required
                ></input>
              </div>
              <div>
                <input
                  type="text"
                  placeholder="Enter Artist's name"
                  className="input"
                  required
                ></input>
              </div>
            </div>
            <br />
            <div className="email-input-div">
              <input
                type="email"
                placeholder="Enter your email"
                className="email-input"
                required
              ></input>
            </div>
          </form>
        </div>
        <div className="cart-billing-modal">
          <div className="cart-billing-divs">
            <h2> Order Summary</h2>
          </div>
          <div className="cart-billing-divs" style={{ textAlign: "start" }}>
            <h3>Bring It</h3>{" "}
          </div>
          <div className="cart-billing-divs">
            <h4> I have read and accept the terms and conditions</h4>
            <button className="pay-btn"> Pay Now </button>
          </div>
        </div>

        {/* payment info div */}

        <div className="payment-info-div">
          <h2>Payment and Billing Information</h2>
          <form className="cart-form">
            <div className="billing-info">
              <div>
                <input
                  type="text"
                  placeholder="Full Name"
                  className="input"
                  required
                ></input>
              </div>
              <div>
                <input
                  type="text"
                  placeholder="Company Name"
                  className="input"
                  required
                ></input>
              </div>
              <div>
                <input
                  type="text"
                  placeholder="Full Address"
                  className="input"
                  required
                ></input>
              </div>
              <div>
                <input
                  type="text"
                  placeholder="City"
                  className="input"
                  required
                ></input>
              </div>
              <div>
                <input
                  type="text"
                  placeholder="State"
                  className="input"
                  required
                ></input>
              </div>
              <div>
                <input
                  type="text"
                  placeholder="Country"
                  className="input"
                  required
                ></input>
              </div>
              <div>
                <input
                  type="number"
                  placeholder="Pin Code"
                  className="input"
                  required
                ></input>
              </div>
              <div>
                <input
                  type="number"
                  placeholder="Phone"
                  className="input"
                  required
                ></input>
              </div>
            </div>
          </form>
        </div>
        <div></div>
      </div>
    </div>
  );
};
export default Explore;
